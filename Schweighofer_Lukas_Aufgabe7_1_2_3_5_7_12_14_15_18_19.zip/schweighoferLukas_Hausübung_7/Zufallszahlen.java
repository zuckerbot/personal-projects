package schweighoferLukas_Haus�bung_7;

public class Zufallszahlen 
{

	public static void main(String[] args) 
	{
		/*Zufallszahlen: Generieren Sie
		1000000 Zufallszahlen von 123400 bis 123499. 
		Geben Sie danach aus, wie oft jede dieser Zahlen erzeugt wurde.
		*/
		
		int zufallszahl;
		final int obergrenze = 123499;
		final int untergrenze = 123400;
		final int anzahl = 1000000;
		int[] h�ufigkeit;
		h�ufigkeit = new int[100];
		
		for (int i = 0; i <= anzahl; i++)
		{
		
			zufallszahl =(int)(Math.random()*(obergrenze-untergrenze+1)+ untergrenze);
			int temp = zufallszahl - untergrenze; 
			h�ufigkeit[temp]++;
		}
		for (int i = 0; i < h�ufigkeit.length; i++)
		{
			System.out.println((i+untergrenze)+": "+h�ufigkeit[i]);
		}
	
	}

}
