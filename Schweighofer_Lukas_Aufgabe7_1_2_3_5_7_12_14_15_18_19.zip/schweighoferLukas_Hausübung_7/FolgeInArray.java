package schweighoferLukas_Haus�bung_7;

public class FolgeInArray 
{

	public static void main(String[] args) 
	{
		/*Berechnen Sie die Folge
		1 ; � ; 1/3 ; � ; 1/5 ; ...
		bis zum 100. Glied (1/100) und speichern 
		Sie alle Glieder in einem Array. 
		Geben Sie danach nur die 
		geraden Elemente des Arrays (das 2., 4., 6., ... ) aus.
		*/
		double folge[];
		folge = new double[101];
		
		for(int i = 1; i <= (folge.length-1); i++)
		{
			folge[i]= (double)1/i;
			if (i % 2 == 0) {System.out.println(folge[i]);}
		}
	}
	

}
