package schweighoferLukas_Haus�bung_7;

import java.util.Scanner;

public class Wuerfel3Mal6 
{

	
	public static void main(String[] args) 
	{
		//Bei diesem Spiel w�rfeln mehrere Personen reihum. 
		//Sieger ist die Person, die als erstes zum dritten Mal einen 6er w�rfelt. 
		//Dies muss nicht in aufeinanderfolgenden Runden geschehen. 
		//W�rfeln mehrere Personen in derselben Runde den dritten Sechser, gibt es mehrere SiegerInnen.
		//Lesen Sie dabei aber Anzahl und die Namen der SpielerInnen ein.
		
		Scanner s = new Scanner(System.in);
		
		String[] spieler;
		System.out.println("Wie viele Spieler? ");
		int anzahlSpieler = s.nextInt();
		
		spieler = new String[anzahlSpieler];
		for(int i=0; i < spieler.length; i++)
		{
			System.out.println("Name des "+(i+1)+". Spielers:");
			spieler[i]= s.next();
		}
		
		int[] sechser;
		sechser = new int[anzahlSpieler];
		boolean letzteRunde = false;
		while(!letzteRunde) {
			for (int i= 0; i < spieler.length; i++) 
			{
				int wurf = (int)(Math.random()*(6-1+1)+1);
				if (wurf == 6)
				{
					sechser[i]++;
				}
				if (sechser[i] == 3) 
				{ 	
					System.out.println(spieler[i]);
					letzteRunde=true;
				}
			}
		}
		s.close();
	}


}
