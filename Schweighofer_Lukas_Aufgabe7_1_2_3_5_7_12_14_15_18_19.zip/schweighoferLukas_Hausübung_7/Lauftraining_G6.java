package schweighoferLukas_Haus�bung_7;

public class Lauftraining_G6 
{

	public static void main(String[] args)
	{
		/* Erstellen Sie ein 2-dimensionales Array, in dem die t�gliche Laufleistung f�r ein Jahr gespeichert werden kann. 
		 * F�llen Sie dieses Array mit Zufallszahlen von 0 bis 25.		[2]
		   Beachten Sie, dass die Monate verschieden viele Tage haben und passen Sie das Array dementsprechend an. Ignorieren Sie dabei, dass es auch Schaltjahre gibt.[3]
				Geben Sie dann die folgenden Informationen aus:
				� An welchem Tag (Monatsname und Tag) wurde die l�ngste Strecke gelaufen?		[2]
				� Eine Statistik der Monate mit der in dem jeweiligen Monat gelaufenen Strecke.		[2]
				�Eine Statistik der Tage im Monat (1., 2., 3., �): Wie weit wurde an diesen Tagen jeweils im Schnitt gelaufen?		[3]
				� An welchen 5 aufeinander folgenden Tagen wurde in Summe die geringste Strecke zur�ckgelegt?				[7]
		*/
		
		double[][] laufleistung = new double[13][];
		double[][] tagesStatistik = new double[31][2];
		double[] alleWerte = new double[365];
		final int obergrenze = 25;
		final int untergrenze = 0;
		double distanz = 0;
		double[] maximum = new double[] {0,1,1};
		
		double summe5tage = 0;
		double geringsteStrecke = 125;
		int jahresindexAnfang = 365;
		int jahresindexEnde = 0;
		int t=0;

		
		for(int i = 1; i < laufleistung.length; i++)
		{	
			
			if(i == 2) {laufleistung[i]  = new double[28];}
			else if (i == 4 || i==6 || i ==9 || i == 11) {laufleistung[i] =new double [30];}
			else  {	laufleistung[i] = new double[31];}
			for(int j = 0; j < laufleistung[i].length; j++)
			{
				distanz =(Math.random()*(obergrenze-untergrenze)+ untergrenze);
				distanz = Math.round(distanz * 100) / 100d;
				laufleistung[i][j] = distanz;
				alleWerte[t] = distanz;
				t++;
				if (distanz > maximum[0])
				{
					maximum[0] = distanz;
					maximum[1] = i;
					maximum[2] = j+1;				
				}
				
			}
		}
	
		/*for(int i = 1; i < laufleistung.length; i++) Ausgabe alle Daten zum nachvollziehen
		{
			for(int j = 0; j < laufleistung[i].length; j++)
			{
				System.out.print(laufleistung[i][j]+";");
				
			}
			System.out.print("\n");
		}*/
		System.out.println("Maximale Laufleistung: "+maximum[0]+" km, gelaufen am "+((int)maximum[2])+". "+(bestimmeMonat((int)maximum[1]))+". \n");
		for(int i = 1; i < laufleistung.length; i++)
		{
			double gesamtStrecke = 0;
			for(int j = 0; j < laufleistung[i].length; j++)
			{
				gesamtStrecke += laufleistung[i][j];
			}
			gesamtStrecke = Math.round(gesamtStrecke * 100) / 100d;
			
			System.out.println("Im "+bestimmeMonat(i)+" wurden "+gesamtStrecke+" km gelaufen.");
		}
		for(int i = 1; i < laufleistung.length; i++)
		{
			for(int j = 0; j < laufleistung[i].length; j++)
			{
				tagesStatistik[j][0] += laufleistung[i][j];
				tagesStatistik[j][1]++;
				
			}
		}
		System.out.println();
		System.out.println("Durchscnittliche Laufleistung pro Tag: \n");
		for(int i =0; i < tagesStatistik.length; i++)
		{
		System.out.println("Am  "+(i+1)+". eines Monats : "+(Math.round((tagesStatistik[i][0] /tagesStatistik[i][1])* 100)/ 100d));
		}
		for(int i = (alleWerte.length - 1); i >= 0; i--)
		{
			if(i > 3)
			{
				summe5tage = (alleWerte[i-4] + alleWerte[i-3] + alleWerte[i-2] + alleWerte[i-1] + alleWerte[i]);
				if(summe5tage < geringsteStrecke)
				{
					geringsteStrecke = summe5tage;
					jahresindexAnfang = (i-4);
					jahresindexEnde = i;
				}
			}
		}
		geringsteStrecke = Math.round(geringsteStrecke*100)/100d;
		//System.out.println(jahresindexAnfang);
		System.out.println("\n"+kleinsteSumme(laufleistung,alleWerte,jahresindexAnfang,jahresindexEnde,geringsteStrecke));

	}
	public static String bestimmeMonat(int monat)
	{
		String kalendermonat = "";
		
		switch(monat)
		{
		case 1: kalendermonat = "J�nner";
			break;
		case 2: kalendermonat = "Februar";
			break;
		case 3: kalendermonat = "M�rz";
			break;
		case 4: kalendermonat = "April";
			break;
		case 5: kalendermonat = "Mai";
			break;
		case 6: kalendermonat = "Juni";
			break;
		case 7: kalendermonat = "Juli";
			break;
		case 8: kalendermonat = "August";
			break;
		case 9: kalendermonat = "September";
			break;
		case 10: kalendermonat = "Oktober";
			break;
		case 11: kalendermonat = "November";
			break;
		case 12: kalendermonat = "Dezember";
			break;
		default: kalendermonat = "nicht vef�gbar";
		}
		return kalendermonat;
	}
	public static String kleinsteSumme(double[][] laufleistung, double[] alleWerte, int anfang, int ende, double geringsteStrecke)
	{	
		int counter = 0;
		String datumsbereichSumme = "Die geringste Strecke von "+ geringsteStrecke + "km wurde zwischen ";
		for(int i = 1; i < laufleistung.length; i++)
		{
			for(int j = 0; j < laufleistung[i].length; j++)
			{
				 
				if(counter == anfang)
				{
					datumsbereichSumme += (j + 1) + ". " + bestimmeMonat(i);
				}
				if(counter == ende)
				{
					datumsbereichSumme += " und " + (j + 1) + ". " + bestimmeMonat(i) + " gelaufen.";
				}
				counter++;
			}
		}
		
		return datumsbereichSumme;
	}
}
