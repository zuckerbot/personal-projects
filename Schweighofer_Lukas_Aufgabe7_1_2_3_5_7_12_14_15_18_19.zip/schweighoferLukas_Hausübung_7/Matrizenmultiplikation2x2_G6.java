package schweighoferLukas_Haus�bung_7;

import java.util.Scanner;

public class Matrizenmultiplikation2x2_G6 
{

	public static void main(String[] args) 
	{
		// TODO Lesen Sie zwei zweidimensionale 2x2 Matrizen ein und 
		//multiplizieren Sie diese. Speichern Sie dabei das Ergebnis in einer dritten Matrix.	
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Um 2 Matrizen zu multiplizieren m�ssen die Spalten von A \nder Zeilenanzahl von B entsprechen.");
		System.out.println("eingelesen werden Matrizen in dieser Form: \na1 a2\na3 a4");
		int[][] matrix1 = new int[2][2];
		int[][] matrix2 = new int[2][2];
		int[][] matrixL�s = new int[2][2];
		
		for (int i = 0; i < matrix1.length; i++ )
		{
			for (int j = 0; j < matrix1[i].length; j++ )
			{
				System.out.println("Geben sie den Wert der 1. Matrix in Zeile "+(i+1)+" und Spalte "+(1+j)+" ein.");
				matrix1[i][j] = s.nextInt();
			}
		}
		for (int i = 0; i < matrix1.length; i++ )
		{
			for (int j = 0; j < matrix1[i].length; j++ )
			{
				System.out.println("Geben sie den Wert der 2. Matrix in Zeile "+(i+1)+" und Spalte "+(1+j)+" ein.");
				matrix2[i][j] = s.nextInt();
			}
		}
		
	
		for(int i = 0; i < matrixL�s.length; i++)
		{
			for(int j = 0; j < matrixL�s[i].length; j++)
			{
				for(int k = 0; k < matrixL�s[i].length; k++)
				{
					matrixL�s[i][j] += matrix1[i][k] * matrix2[k][j];
				}
			}
		}
	
		for (int i = 0; i < matrixL�s.length; i++ )
		{
			for (int j = 0; j < matrixL�s[i].length; j++ )
			{
				System.out.println("L�sungsmatrix in Zeile "+(i+1)+" und Spalte "+(1+j)+": "+matrixL�s[i][j]);
			}
		}
		s.close();
	}

}
