package schweighoferLukas_Haus�bung_7;

import java.util.Scanner;

public class Matrizenaddition2x2_G6 
{

	public static void main(String[] args) 
	{
		//Lesen Sie zwei zweidimensionale 2x2 Matrizen ein 
		//(mit zwei Zeilen und 2 Spalten) und 
		//addieren Sie diese. 
		//Speichern Sie dabei das Ergebnis in einer dritten Matrix.
		
		Scanner s = new Scanner(System.in);
		
		int[][] matrix1 = new int[2][2];
		int[][] matrix2 = new int[2][2];
		int[][] matrixL�s = new int[2][2];
		
		for (int i = 0; i < matrix1.length; i++ )
		{
			for (int j = 0; j < matrix1[i].length; j++ )
			{
				System.out.println("Geben sie den Wert der 1. Matrix in Zeile "+(i+1)+" und Spalte "+(1+j)+" ein.");
				matrix1[i][j] = s.nextInt();
			}
		}
		for (int i = 0; i < matrix1.length; i++ )
		{
			for (int j = 0; j < matrix1[i].length; j++ )
			{
				System.out.println("Geben sie den Wert der 2. Matrix in Zeile "+(i+1)+" und Spalte "+(1+j)+" ein.");
				matrix2[i][j] = s.nextInt();
			}
		}
		
	
		for (int i = 0; i < matrix1.length; i++ )
		{
			for (int j = 0; j < matrix1[i].length; j++ )
			{
				matrixL�s[i][j] = matrix1[i][j] + matrix2[i][j];
			}
	
		}
		for (int i = 0; i < matrixL�s.length; i++ )
		{
			for (int j = 0; j < matrixL�s[i].length; j++ )
			{
				System.out.println("L�sungsmatrix in Zeile "+(i+1)+" und Spalte "+(1+j)+": "+matrixL�s[i][j]);
			}
		}
		s.close();
	
	}

}
