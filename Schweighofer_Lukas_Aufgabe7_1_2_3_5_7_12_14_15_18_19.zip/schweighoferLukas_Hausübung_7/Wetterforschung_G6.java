package schweighoferLukas_Haus�bung_7;

import java.util.Scanner;

public class Wetterforschung_G6 
{
	/*
	 * Erstellen Sie ein Array in dem die monatlichen Durchschnittstemperaturen der Jahre 2000- 2014 
	 * gespeichert werden k�nnen. Fragen Sie nach, ob die Zahlen eingelesen oder zuf�llig ermittelt werden sollen.
	 *  
	 * In letzterem Fall verwenden Sie double Zufallszahlen von -5 bis +25.
	 * 
	 * In wie vielen Monaten war es k�lter als 10 Grad?
	 *  	
	 * Berechnen Sie dann die folgenden Durchschnittstemperaturen und speichern Sie diese jeweils in einem Array 
	 * 		�	der Jahre (also von 2000, 2001, �)		
	 * 		�	der jeweiligen Monate (also von J�nner, Februar, �)
	 * 
	 * Geben Sie dann (basierend auf obigen Arrays)
	 * 		�	das k�lteste Jahr und 		
	 * 		�	den w�rmsten Monat		
	 * aus.
	 */
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		
		final double oberGrenze = 25;
		final double unterGrenze = -5;
		final int jahre = 15;
		final int monate = 12;
		
		int unter10 = 0;
		
		boolean falsch = true;
		
		double[][] wetterdaten = new double[jahre][monate];
		double[] ergebnisJahre = new double[jahre];
		double[] ergebnisMonate = new double[monate];
		
		double temp;
		int kaeltestesJahr = 0;
		int waermsterMonat = 0;
		
		System.out.println("Sollen die Durschnittstemperaturen manuell eingeben werden (ja / nein)? ");
		String manuell = s.next();
		do
		{
			switch(manuell)
			{
				case "ja":
					for(int i = 0; i < jahre; i++)
					{
						for(int j = 0; j < monate; j++)
						{
							System.out.print("Durchschnittstemperatur " + ausgabeMonatsname(j + 1) + "-" + (2000 + i) + ": ");
							wetterdaten[i][j] = s.nextDouble();
							if(wetterdaten[i][j] < 10)
							{
								unter10++;
							}
						}
					}
					falsch = false;
					break;
				case "nein":
					for(int i = 0; i < jahre; i++)
					{
						for(int j = 0; j < monate; j++)
						{
							wetterdaten[i][j] = Math.random() * (oberGrenze - unterGrenze + 1) + unterGrenze;
							if(wetterdaten[i][j] < 10)
							{
								unter10++;
							}
						}
					}
					falsch = false;
					break;
				default: System.out.println("Eingabe nicht erkannt, bitte wiederholen!");
			}
		}while(falsch);
		
		System.out.println("Es war in " + unter10 + " Monaten k�lter als 10�C!");
		
		for(int i = 0; i < jahre; i++)
		{
			for(int j = 0; j < monate; j++)
			{
				ergebnisJahre[i] += wetterdaten[i][j];
			}
			ergebnisJahre[i] /= monate;
		}
		
		for(int i = 0; i < jahre; i++)
		{
			for(int j = 0; j < monate; j++)
			{
				ergebnisMonate[j] += wetterdaten[i][j];
			}
		}
		
		for(int i = 0; i < monate; i++)
		{
			ergebnisMonate[i] /= jahre;
		}
		
		temp = ergebnisJahre[kaeltestesJahr];		
		for(int i = 0; i < jahre; i++)
		{
			if(ergebnisJahre[i] < temp)
			{
				kaeltestesJahr = i;
				temp = ergebnisJahre[i];
			}
		}
		
		temp = ergebnisJahre[waermsterMonat];		
		for(int i = 0; i < monate; i++)
		{
			if(ergebnisMonate[i] < temp)
			{
				waermsterMonat = i;
				temp = ergebnisMonate[i];
			}
		}
		
		System.out.println("Das im Durschnitt k�lteste Jahr: " + (2000 + kaeltestesJahr) + " mit " + ergebnisJahre[kaeltestesJahr] + "�C.");
		System.out.println("Der im Durschnitt w�rmste Monat: " + ausgabeMonatsname(waermsterMonat + 1) + " mit " + ergebnisMonate[waermsterMonat] + "�C.");
		
		s.close();
	}
	public static String ausgabeMonatsname(int index)
	{
		String name = "";
		
		switch(index)
		{
		case 1: name = "J�nner";
			break;
		case 2: name = "Februar";
			break;
		case 3: name = "M�rz";
			break;
		case 4: name = "April";
			break;
		case 5: name = "Mai";
			break;
		case 6: name = "Juni";
			break;
		case 7: name = "Juli";
			break;
		case 8: name = "August";
			break;
		case 9: name = "September";
			break;
		case 10: name = "Oktober";
			break;
		case 11: name = "November";
			break;
		case 12: name = "Dezember";
			break;
		default: name = "FEHLER!";
		}
		return name;
	}
}
