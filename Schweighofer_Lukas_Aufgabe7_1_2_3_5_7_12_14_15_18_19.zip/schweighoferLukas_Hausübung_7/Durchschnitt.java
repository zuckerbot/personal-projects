package schweighoferLukas_Haus�bung_7;

import java.util.Scanner;

public class Durchschnitt 
{

	public static void main(String[] args)
	{
		// TODO 5.	Durchschnitt: Lesen Sie beliebig viele (maximal 50) Zahlen ein 
		//(Abschluss mit 0) und speichern Sie
		//diese in einem Array. Berechnen Sie danach den Durchschnitt der eingelesenen Werte.
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Geben Sie maximal 50 Zahlen (au�er 0) an, nach der letzten beenden Sie das einlesen mit einer 0.");
		System.out.println("Danach wird der Durchschnitt berechnet");
		
		final int maxZahlen = 50;
		double zahlen[];
		zahlen = new double[maxZahlen+1]; // +1 f�r 0
		double summe = 0;
		int anzahl = 0;
		
		for(int i = 0; i < zahlen.length; i++)
		{
			System.out.println("Geben Sie eine Zahl an:");
			zahlen[i]= s.nextDouble();
			summe +=  zahlen[i];
			anzahl++;
			if (zahlen[i] == 0) 
			{	
				anzahl--;
				break; 
			}
			if (anzahl == 50) 
			{	
				System.err.println("Maximale Anzahl an Werten erreicht.");
				break; 
			}
		}
		System.out.println("Der Durchschnitt betr�gt :"+(summe/anzahl));
		s.close();
	}

}
