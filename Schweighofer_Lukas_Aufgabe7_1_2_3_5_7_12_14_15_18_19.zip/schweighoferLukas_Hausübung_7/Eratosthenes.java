package schweighoferLukas_Haus�bung_7;

import java.util.Scanner;

public class Eratosthenes 
{

	public static void main(String[] args) 
	{
		//Eratosthenes: Bestimmen Sie alle Primzahlen bis zu einem gegebenen 
		//n mit Hilfe des �Siebs des Eratosthenes�. 
		// boolean array[n] -> alle false-> kleinster false index = immer Primzahl -> alle vielfachen der Primzahl -> 
	
		Scanner s =  new Scanner(System.in);
		System.out.println("n=");
		int n = s.nextInt();
		
		boolean[] primzahl;
		primzahl = new boolean[n+1]; // false default; "markierung" -> true; Markierung hei�t keine Primzahl
		
		for (int i = 2; i < primzahl.length; i++) //Beginn mit i = 2 wie Sieb
		{
			if (!primzahl[i]) 
			{
				for(int j = (i*i); j < primzahl.length; j++)
				{
					if (j % i == 0)
					{
						primzahl[j] = true;
					}
				}
			}
		}
		for (int i = 2; i < primzahl.length; i++) //Beginn mit i = 2 wie Sieb
		{
			if(!primzahl[i]) {System.out.println(i);}
		}
		s.close();
		
	}	

}
