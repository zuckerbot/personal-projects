package schweighoferLukas_Haus�bung_7;

public class WuerfelDie6 
{

	public static void main(String[] args) 
	{
		/*Bei diesem Spiel wird reihum gew�rfelt. Wer einen 6er w�rfelt, hat das Spiel gewonnen.
		Wird dabei von niemandem ein 6er gew�rfelt, so wird 
		eine neue W�rfelrunde begonnen. Dies wird so lange wiederholt, bis es endlich einen Sieger gibt. 
		W�rfeln innerhalb einer W�rfelrunde mehrere Personen einen 6er, so haben diese alle gewonnen.
		Die Namen der beteiligten Personen sollen fix in einem Array gespeichert sein (Sie m�ssen diese nicht einlesen).
		*/
		
		String[] spieler;
		spieler = new String[]{"Trump","Merkel","Kurz","Kanye West","Putin"};
		
		int anzahl = 0;
	
		do
		{
			for (int i= 0; i < spieler.length; i++) 
			{
			int wurf = (int)(Math.random()*(6-1+1)+1);
			if (wurf == 6)
				{
				System.out.println("Sieger: "+spieler[i]);
				anzahl++;
				}
			}
		} while (anzahl == 0);
	}
}
